# Porównanie wariantów – [Klient]

## Macierz porównawcza
| Opcja | Producent | Temp | Ciśnienie | Odporność | Cena | Dostawa | Dopasowanie |
|---|---|---|---|---|---:|---:|---:|

## Rekomendacja
- ...

## Obiekcje i odpowiedzi
1. ...
