Ćwiczenie: Agent sprzedażowy – porównania

Cel:
Stwórz macierz porównawczą 3 opcji i rekomendację dla klienta.

Pliki wejściowe:
- data/warianty_i_konkurencja.csv
- data/profil_klienta.txt

Wyniki:
- tabela porównawcza + ocena dopasowania (0–5) do profilu,
- 5 argumentów różnicujących dla wybranej opcji,
- 3 obiekcje klienta i odpowiedzi.
