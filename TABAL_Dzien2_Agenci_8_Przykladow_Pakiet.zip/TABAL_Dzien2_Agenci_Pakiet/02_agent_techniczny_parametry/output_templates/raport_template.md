# Raport zgodności – [Produkt] vs [Klient]

## Tabela zgodności
| Obszar | Wymaganie | Produkt | Status | Komentarz |
|---|---|---|---|---|

## Ryzyka
- ...

## Pytania do klienta
1. ...
