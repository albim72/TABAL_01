Ćwiczenie: Agent techniczny – weryfikacja parametrów

Cel:
Porównaj wymagania klienta z kartą produktu i przygotuj raport niezgodności.

Pliki wejściowe:
- data/wymagania_klienta.txt
- data/karta_produktu.txt

Wyniki:
- tabela: wymaganie vs parametr produktu (OK / NIE / BRAK)
- lista ryzyk (techniczne i projektowe)
- lista pytań do klienta (co doprecyzować)
- rekomendacja: czy produkt pasuje? jeśli nie – jakie kierunki alternatywy.
