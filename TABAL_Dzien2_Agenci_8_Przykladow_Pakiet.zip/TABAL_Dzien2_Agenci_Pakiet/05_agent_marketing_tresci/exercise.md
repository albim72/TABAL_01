Ćwiczenie: Agent marketingowy – plan treści

Cel:
Ułóż 2-tygodniowy plan treści (LinkedIn + mailing) dla 2 person. Przygotuj 2 przykładowe posty i 1 mail.

Pliki wejściowe:
- data/brand_voice.md
- data/persony.csv

Wyniki:
- kalendarz publikacji (tabela: data, kanał, temat, CTA),
- 2 posty (różne persony),
- 1 mail (do kupca lub inżyniera UR).
