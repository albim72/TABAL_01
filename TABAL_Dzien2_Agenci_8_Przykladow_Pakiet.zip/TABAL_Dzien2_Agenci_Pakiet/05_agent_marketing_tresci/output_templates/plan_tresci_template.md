# Plan treści – 2 tygodnie

| Data | Kanał | Persona | Temat | CTA | Notatki |
|---|---|---|---|---|---|

## Post 1
...
## Post 2
...
## Mail
...
