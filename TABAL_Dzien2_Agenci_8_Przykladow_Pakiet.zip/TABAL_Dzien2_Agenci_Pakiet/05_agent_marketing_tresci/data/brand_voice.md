# Brand voice TABAL (przykład)
- Styl: rzeczowy, techniczny, ale zrozumiały
- Obietnice: tylko to, co możemy dowieźć
- Słowa kluczowe: niezawodność, zgodność, serwis, bezpieczeństwo
- Unikamy: „najlepszy na rynku”, „rewolucja”, „AI wszystko zrobi”
