Ćwiczenie: Agent zarządzania firmą – OKR i plan tygodnia

Cel:
Na bazie OKR i ryzyk przygotuj plan tygodnia: priorytety, zadania, odpowiedzialni, kryteria sukcesu.

Pliki wejściowe:
- data/okr_i_inicjatywy.csv
- data/ryzyka.csv

Wyniki:
- TOP 3 priorytety tygodnia (z uzasadnieniem),
- tabela zadań (kto, co, kiedy, zależności),
- lista ryzyk i działań mitygujących,
- 3 KPI, które warto śledzić przez 4 tygodnie.
