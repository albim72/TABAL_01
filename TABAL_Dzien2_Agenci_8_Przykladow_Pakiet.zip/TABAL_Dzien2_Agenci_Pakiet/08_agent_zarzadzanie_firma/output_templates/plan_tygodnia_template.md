# Plan tygodnia – operacje

## Priorytety (TOP3)
1. ...

## Zadania
| Właściciel | Zadanie | Termin | Zależności | Kryterium sukcesu |
|---|---|---|---|---|

## Ryzyka i mitigacje
- ...

## KPI na 4 tygodnie
- ...
