Ćwiczenie: Agent analizy rynku

Cel:
Na podstawie danych o segmentach i ankiecie klientów przygotuj 1-stronicowy brief: gdzie i dlaczego warto atakować rynek w pierwszej kolejności.

Pliki wejściowe:
- data/rynek_segmenty.csv
- data/ankieta_klientow.csv

Wyniki:
- 3 wnioski oparte o dane (fakty),
- 3 hipotezy (interpretacje do weryfikacji),
- rekomendacja TOP2 segmentów + uzasadnienie,
- ryzyka i czego brakuje w danych.
