Ćwiczenie: Agent sprzedażowy – oferta

Cel:
Na podstawie briefu klienta i katalogu produktów przygotuj ofertę (1–2 strony) oraz mail przewodni.

Pliki wejściowe:
- data/brief_klienta.txt
- data/katalog_produktow.csv

Wyniki:
- rekomendacja produktu (lub 2 warianty),
- argumentacja (korzyści dla klienta, ryzyka, założenia),
- tabela: cena, lead time, zakres dostawy,
- mail przewodni (krótko i konkretnie).
