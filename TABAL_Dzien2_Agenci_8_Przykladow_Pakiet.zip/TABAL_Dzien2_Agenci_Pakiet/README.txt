Ten pakiet zawiera 8 ćwiczeń projektowania agentów AI w firmie.
Każdy agent ma:
- folder /data z danymi wejściowymi (pliki do „RAG”/kontekstu),
- plik prompt/system_prompt.txt – propozycję roli i zasad,
- plik exercise.md – zadanie dla uczestnika,
- folder /output_templates – wzory rezultatów.

Sposób pracy na szkoleniu:
1) Otwórz exercise.md, przeczytaj cel i kryteria.
2) Załaduj pliki z /data do narzędzia (lub wklej fragmenty).
3) Użyj system_prompt.txt jako „instrukcji roli” dla agenta.
4) Wygeneruj wynik zgodny z template w /output_templates.
5) Zrób krótką weryfikację i korektę.
