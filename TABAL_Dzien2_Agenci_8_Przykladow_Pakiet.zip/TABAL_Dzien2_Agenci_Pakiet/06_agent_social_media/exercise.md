Ćwiczenie: Agent social media – posty i reakcje

Cel:
Przygotuj post LinkedIn (3 wersje długości) promujący wartość produktu/usługi oraz odpowiedzi na 3 komentarze (pytanie/obiekcja/hejt).

Pliki wejściowe:
- data/produkty_i_korzysci.csv
- data/komentarze_symulacja.csv

Wyniki:
- post: krótki, średni, długi,
- 5 hashtagów,
- odpowiedzi na komentarze (każda 2–4 zdania).
