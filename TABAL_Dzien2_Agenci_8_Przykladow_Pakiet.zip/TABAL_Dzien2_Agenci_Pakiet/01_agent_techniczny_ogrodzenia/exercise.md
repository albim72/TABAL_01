Ćwiczenie: Agent techniczny – ogrodzenia

Cel:
Na podstawie współrzędnych działki oblicz obwód (długość ogrodzenia), a następnie przygotuj zestawienie materiałowe i kosztowe.

Pliki wejściowe:
- data/dzialki_wspolrzedne.csv (współrzędne w metrach)
- data/cennik_materialow.csv (cennik przykładowy)

Założenia (możesz je zmienić, ale jawnie):
- działka jest domykana (ostatni punkt łączy się z pierwszym),
- słupki co 2.5 m (zaokrąglij w górę),
- 1 brama i 1 furtka dla każdej działki,
- na każdy słupek: 4 obejmy

Wyniki:
- obwód działki (m),
- liczba słupków, paneli/przęseł (jeśli przyjmiesz moduł 2.5 m), obejm,
- kosztorys w PLN (tabela),
- komentarz: ryzyka i co trzeba doprecyzować u klienta.
